from django.contrib import admin
from .models import Product, Slider


admin.site.register(Product)
admin.site.register(Slider)
